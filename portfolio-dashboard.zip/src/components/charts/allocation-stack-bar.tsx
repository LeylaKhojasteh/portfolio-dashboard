"use client";

import type { AllocationSlice } from "@/types";
import { formatNumber } from "@/lib/format";

interface AllocationStackBarProps {
  slices: AllocationSlice[];
  /** Segment width must exceed this share before a label is drawn inside. */
  labelThreshold?: number;
  className?: string;
}

/**
 * Compact stacked allocation strip. Segment widths are the raw percentages, so
 * the strip is just a second reading of the same dataset the bars and donut use.
 * Under RTL the flex row mirrors with the page, keeping the reading order right
 * to left without any extra logic.
 */
export function AllocationStackBar({
  slices,
  labelThreshold = 11,
  className,
}: AllocationStackBarProps) {
  return (
    <div
      className={`flex h-6 w-full gap-[2px] overflow-hidden rounded-full ${className ?? ""}`}
      role="img"
      aria-label={slices
        .map((slice) => `${slice.label} ${formatNumber(slice.percentage, { digits: 1 })}%`)
        .join(", ")}
    >
      {slices.map((slice) => (
        <span
          key={slice.id}
          title={`${slice.label} ${formatNumber(slice.percentage, { digits: 1 })}%`}
          className="flex min-w-0 items-center justify-center overflow-hidden first:rounded-s-full last:rounded-e-full"
          style={{ width: `${slice.percentage}%`, backgroundColor: slice.color }}
        >
          {slice.percentage >= labelThreshold ? (
            <span className="truncate px-1.5 text-[10px] leading-none font-semibold tracking-[0.06em] text-canvas/90">
              {slice.label}
            </span>
          ) : null}
        </span>
      ))}
    </div>
  );
}